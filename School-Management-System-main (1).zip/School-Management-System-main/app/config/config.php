<?php


// App Link

define('APPROOT', dirname(dirname(__FILE__)));
define('URLROOT', 'http://localhost/school_system/');
define('APPNAME', 'School Management System');


// Create Database Info

define("DB_HOST","localhost");
define("DB_USER","root");
define("DB_PASSWORD","");
define("DB_NAME","cs314");