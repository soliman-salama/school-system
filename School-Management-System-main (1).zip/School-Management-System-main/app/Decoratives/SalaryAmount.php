<?php

 interface SalaryAmount
 {
     
     
     
       function doubleTotalsalary();
     
     
     
     
     
     
     
     
     
}
    
    
    
    
    
    
    








?>