<?php
interface Inotify{
    function update($Sub,$Body);
}

















?>