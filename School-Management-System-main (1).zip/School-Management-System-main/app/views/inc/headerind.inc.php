<!DOCTYPE html>
<html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meat name='viewport' content='width=device-width'>

        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">

        <title> <?php echo APPNAME; ?> </title>
    </head>

    <body>

        <?php include_once 'navbar.php'; ?>
        <div class="container">
    